﻿// 2-6.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>

void function(int x) 
{
	switch (x) 
	{
	case 100:
		printf("1\n");
		break;
	case 1:
		printf("1\n");
		break;
	case 12:
		printf("1\n");
		break;
	case 193:
		printf("1\n");
		break;
	case 174:
		printf("1\n");
		break;
	case 177:
		printf("1\n");
		break;
	/*case 106:
		printf("1\n");
		break;
	case 107:
		printf("1\n");
	case 108:
		printf("1\n");
		break;
	case 109:
		printf("1\n");
		break;*/

	default:
		printf("default\n");
		
	};
};
int main()
{
	/*function(3)*/;
	//while (1)
	//{
	//	printf("1\n");
	//}

	for (int i = 0; i <= 10; i++)
	{
		printf("1\n");
	};

	return 0;
}


