#pragma once
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "30.h"

//#define FilePath L"C:\\fg.exe"
#define FilePath1 L"C:\\Mytest.dll"
#define FilePath L"C:\\Mypad.exe"
//Mypad.exe
int main()
{

	char* FileBuffer = NULL;
	printf("%d\n", sizeof(char*));
	///HMODULE mod=LoadLibrary(L"Dll1.dll");

	//��ʼ����
	BOOL flag = 0;
	flag = FileToFileBuffer(FilePath, &FileBuffer);
	//if (flag)printf("�ļ���ȡ��� %x\n", FileBuffer);
	//OutputReloacationDirtory(FileBuffer);

	//AddNewSectionToExe(FilePath, FilePath1,0x2000);
	//char* Newbuffer = MoveExportDirtory(FileBuffer, FilePath1);
	//char* Newbuffer=MoveRelocationDirtory(FileBuffer,0x12000000);
	//FileBufferToFile(FilePath1, Newbuffer);
	//OutputImportDirtory(FileBuffer);
	//OutputIATDirtory(FileBuffer);
	OutputBoundImportDirtory(FileBuffer);
	system("pause");
	return 0;
}