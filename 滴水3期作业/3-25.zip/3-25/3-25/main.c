#pragma once
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "25.h"

#define FilePath L"C:\\Dll1.dll"
#define FilePath1 L"C:\\Myfg.exe"

int main()
{

	char* FileBuffer = NULL;
	///HMODULE mod=LoadLibrary(L"Dll1.dll");

	//��ʼ����
	BOOL flag = 0;
	flag = FileToFileBuffer(FilePath, &FileBuffer);
	if (flag)printf("�ļ���ȡ��� %x\n", FileBuffer);
	OutputReloacationDirtory(FileBuffer);
	system("pause");
	return 0;
}