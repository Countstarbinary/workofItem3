// 3-10.cpp : ���ļ����� "main" ����������ִ�н��ڴ˴���ʼ��������
//

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "pe.h"

#define FilePath L"C:\\Windows\\System32\\notepad.exe"

void OutputDosHeader(PIMAGE_DOS_HEADER FileDosHeader)
{
	printf("---------------FileDosHeader_start-------------------\n");
	printf("---------------e_magic:%x-------------------\n", FileDosHeader->e_magic);
	printf("---------------e_cblp:%x-------------------\n", FileDosHeader->e_cblp);
	printf("---------------e_cp:%x-------------------\n", FileDosHeader->e_cp);
	printf("---------------e_crlc:%x-------------------\n", FileDosHeader->e_crlc);
	printf("---------------e_cparhdr:%x-------------------\n", FileDosHeader->e_cparhdr);
	printf("---------------e_minalloc:%x-------------------\n", FileDosHeader->e_minalloc);
	printf("---------------e_maxalloc:%x-------------------\n", FileDosHeader->e_maxalloc);
	printf("---------------e_cs:%x-------------------\n", FileDosHeader->e_cs);
	printf("---------------e_sp:%x-------------------\n", FileDosHeader->e_sp);
	printf("---------------e_csum:%x-------------------\n", FileDosHeader->e_csum);
	printf("---------------e_ip:%x-------------------\n", FileDosHeader->e_ip);
	printf("---------------e_cs:%x-------------------\n", FileDosHeader->e_cs);
	printf("---------------e_lfarlc:%x-------------------\n", FileDosHeader->e_lfarlc);
	printf("---------------e_ovno:%x-------------------\n", FileDosHeader->e_ovno);
	printf("---------------e_res:%hx %hx %hx %hx-------------------\n", FileDosHeader->e_res[0], FileDosHeader->e_res[1], FileDosHeader->e_res[2], FileDosHeader->e_res[3] );
	printf("---------------e_oemid:%x-------------------\n", FileDosHeader->e_oemid);
	printf("---------------e_oeminfo:%x-------------------\n", FileDosHeader->e_oeminfo);
	printf("---------------e_res2:%hx %hx %hx %hx %hx %hx %hx %hx %hx %hx -------------------\n", 
		FileDosHeader->e_res2[0], FileDosHeader->e_res2[1], FileDosHeader->e_res2[2], 
		FileDosHeader->e_res2[3], FileDosHeader->e_res2[4], FileDosHeader->e_res2[5], 
		FileDosHeader->e_res2[6], FileDosHeader->e_res2[7], FileDosHeader->e_res2[8], FileDosHeader->e_res2[9]);
	printf("---------------e_lfanew:%x-------------------\n", FileDosHeader->e_lfanew);
	printf("---------------FileDosHeader_end-------------------\n");
	printf("\n");
};

void OutputFileHeader(PIMAGE_FILE_HEADER FileHeader)
{
	printf("---------------FileHeader_start-------------------\n");
	printf("---------------Machine:%x-------------------\n", FileHeader->Machine);
	printf("---------------NumberOfSections:%x-------------------\n", FileHeader->NumberOfSections);
	printf("---------------TimeDateStamp:%x-------------------\n", FileHeader->TimeDateStamp);
	printf("---------------PointerToSymbolTable:%x-------------------\n", FileHeader->PointerToSymbolTable);
	printf("---------------NumberOfSymbols:%x-------------------\n", FileHeader->NumberOfSymbols);
	printf("---------------SizeOfOptionalHeader:%x-------------------\n", FileHeader->SizeOfOptionalHeader);
	printf("---------------Characteristics:%x-------------------\n", FileHeader->Characteristics);
	printf("---------------FileHeader_end-------------------\n");
	printf("\n");
};

void OutputOptionHeader(PIMAGE_OPTIONAL_HEADER OptionHeader)
{
	printf("---------------OptionHeader_start-------------------\n");
	printf("---------------Magic:%x-------------------\n", OptionHeader->Magic);
	printf("---------------MajorLinkerVersion:%x-------------------\n", OptionHeader->MajorLinkerVersion);
	printf("---------------MinorLinkerVersion:%x-------------------\n", OptionHeader->MinorLinkerVersion);
	printf("---------------SizeOfCode:%x-------------------\n", OptionHeader->SizeOfCode);
	printf("---------------SizeOfInitializedData:%x-------------------\n", OptionHeader->SizeOfInitializedData);
	printf("---------------SizeOfUninitializedData:%x-------------------\n", OptionHeader->SizeOfUninitializedData);
	printf("---------------SizeOfUninitializedData:%x-------------------\n", OptionHeader->AddressOfEntryPoint);
	printf("---------------BaseOfCode:%x-------------------\n", OptionHeader->BaseOfCode);
	printf("---------------BaseOfData:%x-------------------\n", OptionHeader->BaseOfData);
	printf("---------------ImageBase:%x-------------------\n", OptionHeader->ImageBase);
	printf("---------------SectionAlignment:%x-------------------\n", OptionHeader->SectionAlignment);
	printf("---------------FileAlignment:%x-------------------\n", OptionHeader->FileAlignment);
	printf("---------------MajorOperatingSystemVersion:%x-------------------\n", OptionHeader->MajorOperatingSystemVersion);
	printf("---------------MinorOperatingSystemVersion:%x-------------------\n", OptionHeader->MinorOperatingSystemVersion);
	printf("---------------MajorImageVersion:%x-------------------\n", OptionHeader->MajorImageVersion);
	printf("---------------MinorImageVersion:%x-------------------\n", OptionHeader->MinorImageVersion);
	printf("---------------MajorSubsystemVersion:%x-------------------\n", OptionHeader->MajorSubsystemVersion);
	printf("---------------MinorSubsystemVersion:%x-------------------\n", OptionHeader->MinorSubsystemVersion);
	printf("---------------Win32VersionValue:%x-------------------\n", OptionHeader->Win32VersionValue);
	printf("---------------SizeOfImage:%x-------------------\n", OptionHeader->SizeOfImage);
	printf("---------------SizeOfHeaders:%x-------------------\n", OptionHeader->SizeOfHeaders);
	printf("---------------CheckSum:%x-------------------\n", OptionHeader->CheckSum);
	printf("---------------Subsystem:%x-------------------\n", OptionHeader->Subsystem);
	printf("---------------DllCharacteristics:%x-------------------\n", OptionHeader->DllCharacteristics);
	printf("---------------SizeOfStackReserve:%x-------------------\n", OptionHeader->SizeOfStackReserve);
	printf("---------------SizeOfStackCommit:%x-------------------\n", OptionHeader->SizeOfStackCommit);
	printf("---------------SizeOfHeapReserve:%x-------------------\n", OptionHeader->SizeOfHeapReserve);
	printf("---------------SizeOfHeapCommit:%x-------------------\n", OptionHeader->SizeOfHeapCommit);
	printf("---------------LoaderFlags:%x-------------------\n", OptionHeader->LoaderFlags);
	printf("---------------NumberOfRvaAndSizes:%x-------------------\n", OptionHeader->NumberOfRvaAndSizes);
	printf("---------------OptionHeader_end-------------------\n", OptionHeader);
	printf("\n");
};

int GetPeHeaders(char* Filepath)
{
	//��ȡ�ļ�
	HANDLE hFile = CreateFile(Filepath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if (hFile == INVALID_HANDLE_VALUE) 
	{
		printf("Failed to open file! Error: %lu\n", GetLastError());
		return 1;
	}

	//��ȡ�ļ���С�����ڲ�����NtQueryInformationFile����ʵ�ֵ�
	DWORD fileSize = GetFileSize(hFile, NULL);

	if (fileSize == INVALID_FILE_SIZE)
	{
		printf("Failed to get file size! Error: %lu\n", GetLastError());
	}
	else
	{
		printf("File size: %lu bytes\n", fileSize);
	}
	
	//�����ڴ�ռ䣬���ڴ���ļ��е�����
	char* Address = malloc(fileSize);
	memset(Address, 0, fileSize);
	int bytesRead = 0;

	//��ȡ�ļ��е����ݵ����Ƿ�����ڴ�ռ���
	ReadFile(hFile, Address, fileSize, &bytesRead, NULL);

	PIMAGE_DOS_HEADER FileDosHeader = (PIMAGE_DOS_HEADER)Address;
	if (FileDosHeader->e_magic != 0x5A4D) 
	{
		printf("���ļ�����PE�ļ�����ȷ�ϣ�\n");
		return 0;
	};

	PIMAGE_NT_HEADERS  NtHeaders = (PIMAGE_NT_HEADERS)(Address+FileDosHeader->e_lfanew);
	if (NtHeaders->Signature!= 0x4550)
	{
		printf("���ļ�����PE�ļ�����ȷ�ϣ�\n");
		return 0;
	};
	OutputDosHeader(FileDosHeader);
	IMAGE_FILE_HEADER FileHeader =NtHeaders->FileHeader;
	OutputFileHeader(&FileHeader);
	IMAGE_OPTIONAL_HEADER OptionHeader = NtHeaders->OptionalHeader;
	OutputOptionHeader(&OptionHeader);


	HANDLE hFile1 = CreateFile(L"C:\\Mynotepad.exe", GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(hFile1, Address, fileSize, &bytesRead, NULL);

	//�ر��ļ����
	CloseHandle(hFile);
	CloseHandle(hFile1);

	return 0;
}


