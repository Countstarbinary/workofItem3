#pragma once

int GetPeHeaders(char* Filepath);