#include "pch.h"
#include "Mytest.h"


int __stdcall Plus(int x, int y)
{
	return x + y;
}
int __stdcall Sub(int x, int y)
{
	return x - y;
}
int __stdcall Mul(int x, int y)
{
	return x * y;
}
int __stdcall Div(int x, int y)
{
	return x / y;
}
