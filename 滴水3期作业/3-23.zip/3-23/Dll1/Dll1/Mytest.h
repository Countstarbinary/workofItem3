#pragma once

extern "C" int __declspec(dllexport) __stdcall Plus(int x, int y);
extern "C" int __declspec(dllexport) __stdcall Sub(int x, int y);
extern "C" int __declspec(dllexport) __stdcall Mul(int x, int y);
extern "C" int __declspec(dllexport) __stdcall Div(int x, int y);

