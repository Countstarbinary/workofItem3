﻿// StaticLib1.cpp : 定义静态库的函数。
//

#include "pch.h"
#include "framework.h"

// TODO: 这是一个库函数示例
void fnStaticLib1()
{
}
